'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const {simulate, rng} = require('./generator.cjs');
const {ScreeningStore} = require('./oracle/claim_screening');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
process.chdir(__dirname);
const original = fs.readFileSync('mc08.cjs','utf8');
const freeze = require('./freeze.json');
for (const [file, component] of [
  ['mc08.cjs','MC08 comparator and original generator'],
  ['oracle/claim_screening.js','MC23 screening store'],
  ['oracle/billing_line.js','MC23 billing-line matching']
]) assert.equal(hash(fs.readFileSync(file)).toUpperCase(),freeze.verifiedSources.find(x=>x.component===component).sha256);
const reference = vm.runInNewContext(original.split('const runs = [];')[0]+';({simulate, rebuiltRules})');

function scores(bills) {
  const lines = new Map(), histories = new Map();
  return bills.map(({provider,kind,amount,serviceKey,lineKey}) => {
    const key = provider+'/'+serviceKey, category = provider+'/'+kind;
    const prior = histories.get(category) || [];
    const sorted = prior.toSorted((a,b)=>a-b);
    const mid = sorted.length >> 1;
    const median = sorted.length % 2 ? sorted[mid] : (sorted[mid-1]+sorted[mid])/2;
    const unusual = prior.length >= 10 && amount/median >= 1.45;
    const extreme = prior.length >= 10 && amount/median >= 1.75;
    const score = 4*Number(lines.get(key)===lineKey)+2*Number(extreme)+Number(unusual)+Number(lines.has(key)&&unusual);
    lines.set(key,lineKey);
    histories.set(category,[...prior.slice(-29),amount]);
    return score;
  });
}

function submissions(rows, seed, missing, wrong) {
  const random = rng(seed);
  const past = new Map();
  return rows.map(({bill,truth})=>{
    const {provider, day, kind, amount, serviceKey, lineKey} = bill;
    const id = provider+'/'+day, timestamp = 1704067200+(day+60)*86400;
    const line = {action:'original',serviceDate:new Date(1704067200000+serviceKey*86400000).toISOString().slice(0,10),
      encounterId:'enc-'+serviceKey,lineId:'line-'+lineKey};
    const token = hash(provider+'/'+truth.occurrence);
    const history = past.get(provider) || [];
    const roll = random(), pick = random();
    if (roll >= missing) {
      const others = history.filter(x=>x!==token);
      const substitute = others.length ? others[Math.floor(pick*others.length)] : hash('unused/'+id);
      line.sourceDraftId = 'draft-'+id;
      line.serviceOccurrenceId = roll < missing+wrong ? substitute : token;
    }
    if (!history.includes(token)) history.push(token);
    past.set(provider,history);
    return {id,timestamp,hospital:'h'+provider,patient:'p'+provider,cpt:'c'+kind,icd:'d'+kind,
      amount:String(Math.round(amount*1e6)),claimReference:'claim-'+id,treatmentReference:'treatment-'+id,billingLine:line};
  });
}

function replay(records) {
  const store = new ScreeningStore(':memory:','ab'.repeat(32),'development',0);
  try {
    return records.map(({submitted})=>store.observe({...submitted,amount:BigInt(submitted.amount)}));
  } finally {store.close();}
}

const report = [];
for (const [seed, keep, collision] of [[71001,.72,.12],[71002,.40,.35]]) {
  const args = [seed,65,120,keep,collision];
  const rows = simulate(...args), bills = rows.map(r=>r.bill);
  const expected = reference.simulate(...args);
  const actual = scores(bills);
  let count=0;
  for (const [i,{bill,truth}] of rows.entries()) {
    if (bill.day<0) continue;
    const ref = expected[count++];
    assert.deepEqual([bill.provider,bill.amount,truth.scenario,truth.label],[ref.provider,ref.base[0],ref.scenario,ref.label]);
    if (truth.scenario === 'duplicate') assert.ok(truth.sourceDay!==null && truth.sourceDay<bill.day);
    assert.equal(actual[i],reference.rebuiltRules(ref));
  }
  assert.equal(count,7800);
  for (const [profile,missing,wrong] of [['correct',0,0],['mixed',.20,.05],['stress',.40,.15]]) {
    const submitted = submissions(rows,seed+99999,missing,wrong);
    const records = submitted.map((item,i)=>({submitted:item,truth:rows[i].truth}));
    const mutated = structuredClone(records);
    for (const row of mutated) row.truth={scenario:'permuted',label:7,occurrence:'irrelevant',sourceDay:12345};
    const left = replay(records), right = replay(mutated);
    assert.deepEqual(left,right);
    assert.deepEqual(records.map(r=>r.submitted),mutated.map(r=>r.submitted));
    report.push({seed,profile,scoreComparisons:count,workerDecisionsCompared:left.length,decisionDigest:hash(JSON.stringify(left))});
  }
}
const result = {developmentOnly:true, evaluationSeedsExecuted:0,report};
const serialized=JSON.stringify(result,null,2);
if(fs.existsSync('reference.json')) assert.deepEqual(result,require('./reference.json'));
fs.writeFileSync('local-result.json',serialized);
console.log('PASS: 15600 comparator scores and 70200 paired worker decisions. Evaluation seeds executed: 0.');
