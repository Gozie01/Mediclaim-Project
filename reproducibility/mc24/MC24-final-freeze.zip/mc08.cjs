"use strict";
function rng(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function simulate(seed, providers, claimsPerProvider, duplicateMatchProbability, repeatCollisionProbability) {
  const random = rng(seed);
  const between = (low, high) => low + (high - low) * random();
  const rows = [];
  for (let provider = 0; provider < providers; provider++) {
    const prices = [between(0.23, 0.63), between(0.32, 0.73), between(0.4, 0.8)];
    const history = prices.map(() => []);
    const seen = new Map();
    let serial = 0;
    for (let day = -60; day < claimsPerProvider; day++) {
      const kind = Math.floor(between(0, prices.length));
      const roll = day < 0 ? 1 : random();
      const scenario = roll < 0.035 ? "duplicate" : roll < 0.07 ? "inflated"
        : roll < 0.10 ? "combined" : roll < 0.15 ? "legitimate_repeat"
        : roll < 0.20 ? "legitimate_high_cost" : "routine";
      const label = Number(["duplicate", "inflated", "combined"].includes(scenario));
      let amount = prices[kind] * between(0.78, 1.22);
      let hour = Math.floor(between(0, 24));
      let rarity = random() < 0.13 ? 0.8 : 0.1;
      let serviceKey = serial++;
      let lineKey = serviceKey;
      if (scenario === "duplicate" || scenario === "legitimate_repeat") {
        const keepKey = random() < (label ? duplicateMatchProbability : 0.45);
        const prior = [...seen.entries()].filter(([, claim]) =>
          claim.kind === kind && day - claim.day <= 30);
        if (prior.length) {
          const [key, claim] = prior[Math.floor(between(0, prior.length))];
          ({ amount, rarity } = claim);
          if (keepKey) {
            serviceKey = key;
            const sameLine = random() < (label ? 0.83 : repeatCollisionProbability);
            if (sameLine) lineKey = claim.lineKey;
          }
        }
      } else if (scenario === "inflated" || scenario === "legitimate_high_cost") {
        amount *= label ? between(1.25, 1.95) : between(1.15, 1.65);
      } else if (scenario === "combined") {
        amount = between(0.79, 1.05);
        hour = Math.floor(between(2, 6));
        rarity = 0.8;
      }
      const comparable = history[kind];
      const relativeAmount = comparable.length >= 5 ? amount / median(comparable) : 1;
      const prior = seen.get(serviceKey);
      const duplicate = Number(Boolean(prior));
      const exactLine = Number(prior?.lineKey === lineKey);
      if (day >= 0) rows.push({
        provider, scenario, label,
        base: [amount, hour / 24, rarity, 0.3],
        relativeAmount, duplicate, exactLine, historyCount: comparable.length
      });
      // All prior observed submissions enter history, independent of their label.
      seen.set(serviceKey, { day, kind, amount, rarity, lineKey });
      comparable.push(amount);
      if (comparable.length > 30) comparable.shift();
    }
  }
  return rows;
}

function evaluate(rows, decision) {
  const groups = {};
  for (const row of rows) {
    const group = groups[row.scenario] ??= { count: 0, alerts: 0, label: row.label };
    group.count++;
    group.alerts += decision(row.score);
  }
  const sum = (label, key) => Object.values(groups).filter(g => g.label === label)
    .reduce((total, g) => total + g[key], 0);
  const tp = sum(1, "alerts"), fp = sum(0, "alerts");
  const positives = sum(1, "count"), negatives = sum(0, "count");
  return { tp, fp, positives, negatives, recall: tp / positives,
    falseAlertsPer1000: 1000 * fp / negatives, groups };
}


function rebuiltRules(row) {
  const unusualAmount = row.historyCount >= 10 && row.relativeAmount >= 1.45;
  const extremeAmount = row.historyCount >= 10 && row.relativeAmount >= 1.75;
  // A weaker service match contributes only when the amount is also unusual.
  return 4 * row.exactLine + 2 * Number(extremeAmount) + Number(unusualAmount) +
    Number(row.duplicate && unusualAmount);
}

const runs = [];
for (const [name, start, keep, collide] of [
  ["primary", 10001, 0.72, 0.12], ["repeat_stress", 20001, 0.40, 0.35]
]) {
  for (let seed = start; seed < start + 20; seed++) {
    const rows = simulate(seed, 65, 120, keep, collide);
    for (const row of rows) row.score = rebuiltRules(row);
    runs.push({name, seed, ...evaluate(rows, s => Number(s >= 3))});
  }
}
console.log(JSON.stringify({node:process.version, cutoff:3,runs}, null, 2));
