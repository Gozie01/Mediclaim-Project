"use strict";
function rng(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function simulate(seed, providers, claimsPerProvider, duplicateMatchProbability, repeatCollisionProbability) {
  const random = rng(seed);
  const between = (low, high) => low + (high - low) * random();
  const rows = [];
  for (let provider = 0; provider < providers; provider++) {
    const prices = [between(0.23, 0.63), between(0.32, 0.73), between(0.4, 0.8)];
    const history = prices.map(() => []);
    const seen = new Map();
    let serial = 0;
    for (let day = -60; day < claimsPerProvider; day++) {
      const kind = Math.floor(between(0, prices.length));
      const roll = day < 0 ? 1 : random();
      const scenario = roll < 0.035 ? "duplicate" : roll < 0.07 ? "inflated"
        : roll < 0.10 ? "combined" : roll < 0.15 ? "legitimate_repeat"
        : roll < 0.20 ? "legitimate_high_cost" : "routine";
      const label = Number(["duplicate", "inflated", "combined"].includes(scenario));
      let amount = prices[kind] * between(0.78, 1.22);
      let hour = Math.floor(between(0, 24));
      let rarity = random() < 0.13 ? 0.8 : 0.1;
      let serviceKey = serial++;
      let lineKey = serviceKey;
      let occurrence = serviceKey;
      let sourceDay = null;
      if (scenario === "duplicate" || scenario === "legitimate_repeat") {
        const keepKey = random() < (label ? duplicateMatchProbability : 0.45);
        const prior = [...seen.entries()].filter(([, claim]) =>
          claim.kind === kind && day - claim.day <= 30);
        if (prior.length) {
          const [key, claim] = prior[Math.floor(between(0, prior.length))];
          ({ amount, rarity } = claim);
          if (scenario === "duplicate") { occurrence = claim.occurrence; sourceDay = claim.day; }
          if (keepKey) {
            serviceKey = key;
            const sameLine = random() < (label ? 0.83 : repeatCollisionProbability);
            if (sameLine) lineKey = claim.lineKey;
          }
        }
      } else if (scenario === "inflated" || scenario === "legitimate_high_cost") {
        amount *= label ? between(1.25, 1.95) : between(1.15, 1.65);
      } else if (scenario === "combined") {
        amount = between(0.79, 1.05);
        hour = Math.floor(between(2, 6));
        rarity = 0.8;
      }
      rows.push({ bill: {provider, day, kind, amount, serviceKey, lineKey},
        truth: {scenario, label, occurrence, sourceDay} });
      seen.set(serviceKey, {day, kind, amount, rarity, lineKey, occurrence});
    }
  }
  return rows;
}


module.exports = {simulate, rng};
