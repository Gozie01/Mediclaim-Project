'use strict';
const {rng} = require('./generator.cjs');
const {ScreeningStore} = require('./oracle/claim_screening');
const hash = v => require('node:crypto').createHash('sha256').update(v).digest('hex');
function scores(bills) {
  const lines = new Map(), histories = new Map();
  return bills.map(({provider,kind,amount,serviceKey,lineKey}) => {
    const key = provider+'/'+serviceKey, category = provider+'/'+kind;
    const prior = histories.get(category) || [];
    const sorted = prior.toSorted((a,b)=>a-b);
    const mid = sorted.length >> 1;
    const median = sorted.length % 2 ? sorted[mid] : (sorted[mid-1]+sorted[mid])/2;
    const unusual = prior.length >= 10 && amount/median >= 1.45;
    const extreme = prior.length >= 10 && amount/median >= 1.75;
    const score = 4*Number(lines.get(key)===lineKey)+2*Number(extreme)+Number(unusual)+Number(lines.has(key)&&unusual);
    lines.set(key,lineKey);
    histories.set(category,[...prior.slice(-29),amount]);
    return score;
  });
}

function submissions(rows, seed, missing, wrong) {
  const random = rng(seed);
  const past = new Map();
  return rows.map(({bill,truth})=>{
    const {provider, day, kind, amount, serviceKey, lineKey} = bill;
    const id = provider+'/'+day, timestamp = 1704067200+(day+60)*86400;
    const line = {action:'original',serviceDate:new Date(1704067200000+serviceKey*86400000).toISOString().slice(0,10),
      encounterId:'enc-'+serviceKey,lineId:'line-'+lineKey};
    const token = hash(provider+'/'+truth.occurrence);
    const history = past.get(provider) || [];
    const roll = random(), pick = random();
    if (roll >= missing) {
      const others = history.filter(x=>x!==token);
      const substitute = others.length ? others[Math.floor(pick*others.length)] : hash('unused/'+id);
      line.sourceDraftId = 'draft-'+id;
      line.serviceOccurrenceId = roll < missing+wrong ? substitute : token;
    }
    if (!history.includes(token)) history.push(token);
    past.set(provider,history);
    return {id,timestamp,hospital:'h'+provider,patient:'p'+provider,cpt:'c'+kind,icd:'d'+kind,
      amount:String(Math.round(amount*1e6)),claimReference:'claim-'+id,treatmentReference:'treatment-'+id,billingLine:line};
  });
}

function replay(records) {
  const store = new ScreeningStore(':memory:','ab'.repeat(32),'development',0);
  try {
    return records.map(({submitted})=>store.observe({...submitted,amount:BigInt(submitted.amount)}));
  } finally {store.close();}
}

module.exports = {scores, submissions, replay};
