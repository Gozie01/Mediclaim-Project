'use strict';
const {rng} = require('./generator.cjs');
const endpoints = ['trueRebill','legitimateRepeat','negative','positive','duplicate','inflated','combined'];
function groups(truth) {
  const {scenario,label,sourceDay} = truth;
  const keys = [label ? 'positive' : 'negative'];
  if (scenario === 'duplicate' && sourceDay !== null) keys.push('trueRebill');
  if (scenario === 'legitimate_repeat') keys.push('legitimateRepeat');
  if (['duplicate','inflated','combined'].includes(scenario)) keys.push(scenario);
  return keys;
}
function quantile(sorted,p) {
  const index = (sorted.length-1)*p, lo=Math.floor(index);
  return sorted[lo]+(index-lo)*(sorted[Math.ceil(index)]-sorted[lo]);
}
// A triple stores the denominator, comparator alerts and worker alerts.
function summarize(triples,scale) {
  const sum = samples => samples.reduce((a,b)=>a.map((v,i)=>v+b[i]),[0,0,0]);
  const [n,c,w] = sum(triples);
  const random = rng(82024);
  const deltas=[];
  for(let i=0;i<10000;i++){
    const sampled=Array.from({length:triples.length},()=>triples[Math.floor(random()*triples.length)]);
    const [total,comparator,worker]=sum(sampled);
    if(total) deltas.push(scale*(worker-comparator)/total);
  }
  deltas.sort((a,b)=>a-b);
  return {n,comparatorAlerts:c,workerAlerts:w,comparatorRate:n?scale*c/n:null,workerRate:n?scale*w/n:null,
    difference:n?scale*(w-c)/n:null,validDraws:deltas.length,
    interval:deltas.length===10000?[quantile(deltas,.025),quantile(deltas,.975)]:null};
}
module.exports={endpoints,groups,summarize};
