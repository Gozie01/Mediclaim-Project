'use strict';
const fs=require('node:fs'), crypto=require('node:crypto'), assert=require('node:assert/strict');
process.chdir(__dirname);
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const [name,hash] of Object.entries(JSON.parse(fs.readFileSync('manifest.json')))){
  assert.equal(digest(fs.readFileSync(name)),hash,name);
}
const {simulate}=require('./generator.cjs');
const {scores,submissions,replay}=require('./adapters.cjs');
const {endpoints,groups,summarize}=require('./analysis.cjs');
const design=JSON.parse(fs.readFileSync('design.json','utf8').replace(/^\uFEFF/,''));
const dev=process.argv[2]==='--verify';
assert.ok(dev || process.argv[2]==='--evaluate','Choose --verify or --evaluate');
if(dev){
  assert.deepEqual(groups({scenario:'duplicate',label:1,sourceDay:null}),['positive','duplicate']);
  assert.deepEqual(groups({scenario:'duplicate',label:1,sourceDay:0}),['positive','trueRebill','duplicate']);
  assert.deepEqual(groups({scenario:'combined',label:1,sourceDay:null}),['positive','combined']);
  assert.deepEqual(summarize([[2,1,2],[4,2,4]],100).interval,[50,50]);
  assert.equal(summarize([[0,0,0]],100).difference,null);
  assert.equal(summarize([[2,0,2],[8,8,0]],100).difference,-60);
}
const profiles=[['correct',0,0],['mixed',.20,.05],['stress',.40,.15]];
const refs=require('./reference.json').report;
const records=[];
for(const [cohort,seeds,keep,collision] of [
  ['primary',dev?[71001]:design.primarySeeds,.72,.12],
  ['repeatStress',dev?[71002]:design.repeatStressSeeds,.40,.35]
]){
  for(const seed of seeds){
    const rows=simulate(seed,65,120,keep,collision);
    const cmp=scores(rows.map(r=>r.bill));
    assert.equal(rows.length,11700);
    for(const [profile,missing,wrong] of profiles){
      const inputs=submissions(rows,seed+99999,missing,wrong);
      const outcomes=replay(inputs.map(submitted=>({submitted})));
      if(dev) assert.equal(digest(JSON.stringify(outcomes)),refs.find(r=>r.seed===seed&&r.profile===profile).decisionDigest);
      const counts=Object.fromEntries(endpoints.map(k=>[k,[0,0,0]]));
      let unresolved=0;
      for(const [i,{bill,truth}] of rows.entries()){
        if(bill.day<0) continue;
        if(truth.scenario==='duplicate' && truth.sourceDay===null) unresolved++;
        for(const key of groups(truth)){
          const triple=counts[key];
          triple[0]++;
          triple[1]+=Number(cmp[i]>=3);
          triple[2]+=Number(outcomes[i].decision==='REVIEW');
        }
      }
      assert.equal(counts.positive[0]+counts.negative[0],7800);
      assert.equal(counts.duplicate[0]-counts.trueRebill[0],unresolved);
      records.push({cohort,seed,profile,unresolved,counts});
    }
  }
}
const summary=[];
for(const cohort of ['primary','repeatStress']){
  for(const [profile] of profiles){
    const subset=records.filter(r=>r.cohort===cohort && r.profile===profile);
    for(const key of endpoints) summary.push({cohort,profile,endpoint:key,
      ...summarize(subset.map(r=>r.counts[key]),key==='negative'?1000:100)});
  }
}
const file=(dev?'development':'evaluation')+'-'+Date.now()+'.json';
fs.writeFileSync(file,JSON.stringify({mode:dev?'development':'evaluation',node:process.version,
  manifestSHA256:digest(fs.readFileSync('manifest.json')),records,summary},null,2),{flag:'wx'});
console.log(dev?'PASS: frozen analysis controls and six development decision digests. Reserved seeds executed: 0.':'Completed all 40 held-out seeds.');
console.log('Evidence file:',file);
